<?php
session_start();
if (!isset($_SESSION['loginKey'])) {
    header('location:login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pendaftaran</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php include 'sidebar-pendaftar.php'; ?>

    <h1>Form Pendaftaran OSIS/MPK</h1>

    <form action="create.php" method="POST">
        Nama Lengkap:
        <input type="text" name="namaLengkap" required>
        <br><br>

        Organisasi:
        <input type="radio" name="organisasi" value="OSIS" required> OSIS
        <input type="radio" name="organisasi" value="MPK"> MPK
        <br><br>

        Jabatan:
        <select name="jabatan">
            <option value="Ketua">Ketua</option>
            <option value="Sekretaris">Sekretaris</option>
            <option value="Bendahara">Bendahara</option>
            <option value="Anggota">Anggota</option>
        </select>
        <br><br>

        Visi / Misi:
        <textarea name="visiMisi" rows="4" cols="40" required></textarea>
        <br><br>

        Tanggal Daftar:
        <input type="date" name="tanggalDaftar" required>
        <br><br>

        <button type="submit">Daftar</button>
    </form>

</body>
</html>
