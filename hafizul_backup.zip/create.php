<?php
session_start();
if (!isset($_SESSION['loginKey'])) {
    header('location:login.php');
}

include 'koneksi-db.php';

$namaLengkap   = $_POST['namaLengkap'];
$organisasi    = $_POST['organisasi'];
$jabatan       = $_POST['jabatan'];
$visiMisi      = $_POST['visiMisi'];
$tanggalDaftar = $_POST['tanggalDaftar'];
$status        = "Menunggu";

mysqli_query($koneksi, "INSERT INTO tb_pendaftaran (nama_lengkap, organisasi, jabatan, visi_misi, tanggal_daftar, status) VALUES ('$namaLengkap', '$organisasi', '$jabatan', '$visiMisi', '$tanggalDaftar', '$status')");

header('location:pendaftar.php');
?>
