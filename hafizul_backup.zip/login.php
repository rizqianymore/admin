<?php
session_start();

if (isset($_POST['buttonLogin'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username == 'aira' && $password == 'pearce') {
        $_SESSION['loginKey'] = TRUE;
        header('location:index.php');
    } else if ($username == 'admin' && $password == 'admin') {
        $_SESSION['adminKey'] = TRUE;
        header('location:admin/index.php');
    } else {
        echo "<script>alert('Username atau password salah!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <form action="" method="POST">
        Username:
        <input type="text" name="username" placeholder="Username" required>
        <br><br>

        Password:
        <input type="password" name="password" placeholder="Password" required>
        <br><br>

        <button type="submit" name="buttonLogin">Login</button>
    </form>

</body>
</html>
