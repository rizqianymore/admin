<div class="sidebar">
    <div class="sidebar-brand">
        <div class="brand-mark">O</div>
        <div class="brand-name">OSIS / MPK</div>
    </div>
    <div class="sidebar-nav">
        <a href="index.php" class="nav-item">Form Pendaftaran</a>
        <a href="pendaftar.php" class="nav-item">Data Pendaftar</a>
    </div>
    <div class="sidebar-footer">
        <a href="logout.php" class="nav-item">Logout</a>
    </div>
</div>
