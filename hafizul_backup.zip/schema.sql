CREATE DATABASE IF NOT EXISTS `UKK - HAFIZHUL F.A XI RPL 05`;
USE `UKK - HAFIZHUL F.A XI RPL 05`;

CREATE TABLE tb_pendaftaran (
  id int(11) NOT NULL AUTO_INCREMENT,
  nama_lengkap varchar(250) NOT NULL,
  organisasi varchar(15) NOT NULL,
  jabatan varchar(30) NOT NULL,
  visi_misi varchar(250) NOT NULL,
  tanggal_daftar date NOT NULL,
  status varchar(20) NOT NULL,
  PRIMARY KEY (id)
);
