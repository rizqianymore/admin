<?php
session_start();
if (!isset($_SESSION['adminKey'])) {
    header('location:../login.php');
}

include '../koneksi-db.php';

$id = $_GET['id'];
mysqli_query($koneksi, "DELETE FROM tb_pendaftaran WHERE id='$id'");

header('location:index.php');
?>
