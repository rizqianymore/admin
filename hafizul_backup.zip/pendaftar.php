<?php
session_start();
if (!isset($_SESSION['loginKey'])) {
    header('location:login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pendaftar</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php include 'sidebar-pendaftar.php'; ?>

    <h1>Data Pendaftar OSIS/MPK</h1>

    <table border="1">
        <tr>
            <th>No</th>
            <th>Nama Lengkap</th>
            <th>Organisasi</th>
            <th>Jabatan</th>
            <th>Visi / Misi</th>
            <th>Tanggal Daftar</th>
            <th>Status</th>
        </tr>

        <?php
        $no = 1;
        include 'koneksi-db.php';
        $tampilData = mysqli_query($koneksi, "SELECT * FROM tb_pendaftaran");
        while ($pendaftar = mysqli_fetch_array($tampilData)) {
            echo "<tr>";
            echo "<td>" . $no++ . "</td>";
            echo "<td>" . $pendaftar['nama_lengkap'] . "</td>";
            echo "<td>" . $pendaftar['organisasi'] . "</td>";
            echo "<td>" . $pendaftar['jabatan'] . "</td>";
            echo "<td>" . $pendaftar['visi_misi'] . "</td>";
            echo "<td>" . $pendaftar['tanggal_daftar'] . "</td>";
            echo "<td>" . $pendaftar['status'] . "</td>";
            echo "</tr>";
        }
        ?>
    </table>

</body>
</html>
