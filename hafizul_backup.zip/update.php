<?php
session_start();
if (!isset($_SESSION['adminKey'])) {
    header('location:../login.php');
}

include '../koneksi-db.php';

$id            = $_POST['id'];
$namaLengkap   = $_POST['namaLengkap'];
$organisasi    = $_POST['organisasi'];
$jabatan       = $_POST['jabatan'];
$visiMisi      = $_POST['visiMisi'];
$tanggalDaftar = $_POST['tanggalDaftar'];
$status        = $_POST['status'];

mysqli_query($koneksi, "UPDATE tb_pendaftaran SET nama_lengkap='$namaLengkap', organisasi='$organisasi', jabatan='$jabatan', visi_misi='$visiMisi', tanggal_daftar='$tanggalDaftar', status='$status' WHERE id='$id'");

header('location:index.php');
?>
