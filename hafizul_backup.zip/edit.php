<?php
session_start();
if (!isset($_SESSION['adminKey'])) {
    header('location:../login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Pendaftar</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

    <?php include 'sidebar-admin.php'; ?>

    <h1>Update Pendaftar</h1>

    <?php
    include '../koneksi-db.php';
    $id = $_GET['id'];
    $tampilData = mysqli_query($koneksi, "SELECT * FROM tb_pendaftaran WHERE id = $id");
    while ($pendaftar = mysqli_fetch_array($tampilData)) {
    ?>

    <form action="update.php" method="POST">
        ID:
        <input type="text" readonly name="id" value="<?php echo $pendaftar['id']; ?>">
        <br><br>

        Nama Lengkap:
        <input type="text" name="namaLengkap" value="<?php echo $pendaftar['nama_lengkap']; ?>">
        <br><br>

        Organisasi:
        <input type="radio" name="organisasi" value="OSIS" <?php if ($pendaftar['organisasi'] == 'OSIS') echo 'checked'; ?>> OSIS
        <input type="radio" name="organisasi" value="MPK" <?php if ($pendaftar['organisasi'] == 'MPK') echo 'checked'; ?>> MPK
        <br><br>

        Jabatan:
        <select name="jabatan">
            <option value="Ketua" <?php if ($pendaftar['jabatan'] == 'Ketua') echo 'selected'; ?>>Ketua</option>
            <option value="Sekretaris" <?php if ($pendaftar['jabatan'] == 'Sekretaris') echo 'selected'; ?>>Sekretaris</option>
            <option value="Bendahara" <?php if ($pendaftar['jabatan'] == 'Bendahara') echo 'selected'; ?>>Bendahara</option>
            <option value="Anggota" <?php if ($pendaftar['jabatan'] == 'Anggota') echo 'selected'; ?>>Anggota</option>
        </select>
        <br><br>

        Visi / Misi:
        <textarea name="visiMisi" rows="4" cols="40"><?php echo $pendaftar['visi_misi']; ?></textarea>
        <br><br>

        Tanggal Daftar:
        <input type="date" name="tanggalDaftar" value="<?php echo $pendaftar['tanggal_daftar']; ?>">
        <br><br>

        Status:
        <select name="status">
            <option value="Menunggu" <?php if ($pendaftar['status'] == 'Menunggu') echo 'selected'; ?>>Menunggu</option>
            <option value="Diterima" <?php if ($pendaftar['status'] == 'Diterima') echo 'selected'; ?>>Diterima</option>
            <option value="Ditolak" <?php if ($pendaftar['status'] == 'Ditolak') echo 'selected'; ?>>Ditolak</option>
        </select>
        <br><br>

        <button type="submit">Simpan</button>
    </form>

    <?php } ?>

    <a href="index.php">Kembali</a>

</body>
</html>
