<?php
$koneksi = mysqli_connect("localhost", "root", "", "UKK - HAFIZHUL F.A XI RPL 05");
?>
